import React, { useEffect, useState } from 'react';
import VideoPlayer from './components/VideoPlayer';

export default function App() {
  const [channels, setChannels] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [current, setCurrent] = useState(null);
  const categories = ['All', 'News', 'Sports', 'Movies', 'Music'];

  useEffect(() => {
    fetch('/playlist.m3u')
      .then(res => res.text())
      .then(text => {
        const lines = text.split('\n').filter(line => line && !line.startsWith('#'));
        const parsed = lines.map(url => ({
          name: url.split('/').pop(),
          url,
          category: 'All'
        }));
        setChannels(parsed);
        setCurrent(parsed[0]);
      });
  }, []);

  const filtered = channels.filter(c =>
    (category === 'All' || c.category === category) &&
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <header className="p-4 text-center text-2xl font-bold border-b border-gray-700">PH PA & MA TV</header>
      {current && <VideoPlayer src={current.url} />}
      <div className="p-4">
        <input
          type="text"
          placeholder="Search channels..."
          className="w-full p-2 mb-4 rounded bg-gray-800 border border-gray-600 text-white"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className="flex gap-2 overflow-x-auto mb-4">
          {categories.map(cat => (
            <button
              key={cat}
              className={`px-3 py-1 rounded-full text-sm ${cat === category ? 'bg-blue-500' : 'bg-gray-700'}`}
              onClick={() => setCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4">
          {filtered.map(channel => (
            <div
              key={channel.url}
              className="bg-gray-800 p-2 rounded cursor-pointer hover:bg-gray-700"
              onClick={() => setCurrent(channel)}
            >
              {channel.name}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}