import React, { useRef, useEffect } from 'react';
import Hls from 'hls.js';
import dashjs from 'dashjs';

export default function VideoPlayer({ src }) {
  const videoRef = useRef(null);

  useEffect(() => {
    const video = videoRef.current;
    video.pause();
    video.removeAttribute('src');

    if (/\.m3u8|\.ts($|\?)/i.test(src)) {
      if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = src;
      } else if (Hls.isSupported()) {
        const hls = new Hls();
        hls.loadSource(src);
        hls.attachMedia(video);
      }
    } else if (/\.mpd($|\?)/i.test(src)) {
      const player = dashjs.MediaPlayer().create();
      player.initialize(video, src, true);
    } else {
      video.src = src;
    }
    video.load();
  }, [src]);

  return (
    <div className="bg-black">
      <video ref={videoRef} controls playsInline className="w-full max-h-60 object-contain" />
    </div>
  );
}